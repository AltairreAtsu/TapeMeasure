Tape Measure 
by Quill Inkwell
Version 0.3

Installation Instructions:
===============================================
The following zip is packaged to allow for easy installation of the Mod into your game.
Simply extract the contents of the provided zip file into your CyubeVR Mods Folder.
"cyubeVR/cyubeVR/Mods"
If you are updating the mod allow it to overwrite any existing mod files it encounters.

Usage Instructions:
===============================================
Once installed craft the Tape Measure Start and Tape Measure end blocks found in the "Tape Measure" category.
To use simply place the Tape Measure start block wherever you would like to begin your measurement.
Next place the Tape Measure end block wherever you would like to end your measurement.
These blocks do not need to be in line and it is even possible to measure a 3d volume.
To measure the distance simply tap either block with a stick.

Uninstallation Instructions:
===============================================
Simply delete the TapeMeasure__V1 mod from the "APIMods" folder.
To remove the blocks delete the following folders from your "Blocks" folder:
quillTapeMeasure
quillTapeMeasureEnd